
"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import type { ReactNode } from "react";

import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  CalendarDays,
  CheckCircle2,
  Clock3,
  Columns3,
  Database,
  FileSpreadsheet,
  Play,
  RefreshCw,
  Rows3,
  ShieldCheck,
  TriangleAlert,
  XCircle,
} from "lucide-react";

import PageHeader from "@/components/layout/PageHeader";
import WorkspaceLayout from "@/components/layout/WorkspaceLayout";
import DatasetStatusBadge from "@/components/datasets/DatasetStatusBadge";
import EmptyState from "@/components/common/EmptyState";
import ErrorState from "@/components/common/ErrorState";

import {
  getDataset,
  getDatasetProcessingResult,
} from "@/api/datasets";

import type { DatasetProfile } from "@/api/datasets";
import {
  requestTeam2Quality,
  requestTeam2Semantic,
  TEAM2_UNVERSIONED_DATASET_VERSION,
} from "@/api/team2-contract";
import type { Team2QualityResponse } from "@/api/team2-contract";

import type { Dataset } from "@/types/dataset";
import type { SemanticHandoffResult } from "@/types/semantic";

import {
  formatDatasetDate,
  formatDatasetNumber,
} from "@/lib/dataset-format";

// Dataset workspace navigation
const sections = [
  { key: "overview", label: "Overview", slug: "" },
  { key: "quality", label: "Data Quality", slug: "quality" },
  { key: "columns", label: "Columns", slug: "columns" },
  { key: "distributions", label: "Distributions", slug: "distributions" },
  { key: "correlations", label: "Correlations", slug: "correlations" },
  { key: "semantic", label: "Semantic Understanding", slug: "semantic" },
  { key: "recommendations", label: "Recommendations", slug: "recommendations" },
] as const;

// Page descriptions
const descriptions: Record<string, string> = {
  overview: "Review dataset metadata and run Team 2 data profiling.",
  quality:
    "Run Team 2 validation against a registered dataset and inspect its issue logs.",
  columns:
    "Inspect inferred data types, missing values, unique values and descriptive statistics.",
  distributions:
    "Explore numeric histograms and categorical top values returned by profiling.",
  correlations:
    "Inspect the correlation output returned by the profiling service.",
  semantic:
    "Review semantic column understanding, target suggestions, problem type, feature roles and leakage checks from Team 2.",
  recommendations:
    "Recommendations are not included in the current Team 2 profiling or quality contracts.",
};

type AnyRecord = Record<string, unknown>;

// Helpers
function asRecord(value: unknown): AnyRecord | null {
  return typeof value === "object" && value !== null && !Array.isArray(value)
    ? (value as AnyRecord)
    : null;
}

function numberValue(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value)
    ? value
    : null;
}

function display(value: unknown): string {
  if (value === null || value === undefined || value === "") {
    return "—";
  }

  if (typeof value === "number") {
    return value.toLocaleString(undefined, {
      maximumFractionDigits: 3,
    });
  }

  if (typeof value === "string" || typeof value === "boolean") {
    return String(value);
  }

  return JSON.stringify(value);
}

// Reusable panel
function Panel({
  title,
  description,
  children,
}: {
  title: string;
  description?: string;
  children: ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6">
      <div className="mb-4">
        <h2 className="font-semibold text-slate-950">{title}</h2>

        {description && (
          <p className="mt-1 text-sm text-slate-500">
            {description}
          </p>
        )}
      </div>

      {children}
    </section>
  );
}

// Reusable metric card
function Metric({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string;
  icon: typeof Database;
}) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4">
      <div className="flex items-center justify-between text-sm text-slate-500">
        <span>{label}</span>
        <Icon className="h-4 w-4" />
      </div>

      <p className="mt-2 text-xl font-semibold text-slate-950">
        {value}
      </p>
    </div>
  );
}

// Reusable error list
function ErrorList({
  title,
  items,
}: {
  title: string;
  items: unknown[];
}) {
  if (!items.length) {
    return (
      <p className="rounded-lg bg-emerald-50 p-3 text-sm text-emerald-800">
        No {title.toLowerCase()} returned.
      </p>
    );
  }

  return (
    <ul className="space-y-2">
      {items.map((item, index) => {
        const obj = asRecord(item);

        const message = obj
          ? obj.message ??
            obj.description ??
            obj.detail ??
            JSON.stringify(obj)
          : item;

        return (
          <li
            key={index}
            className="flex gap-2 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900"
          >
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
            {display(message)}
          </li>
        );
      })}
    </ul>
  );
}

// Main dataset workspace
export default function DatasetWorkspaceView({
  section,
}: {
  section: string;
}) {
  const pathname = usePathname();

  const datasetId =
    pathname.split("/").filter(Boolean)[1] ?? "";

  const base = `/datasets/${datasetId}`;

  const active =
    sections.find((item) => item.key === section) ?? sections[0];

  const navigation = sections.map((item) => ({
    label: item.label,
    href: item.slug ? `${base}/${item.slug}` : base,
  }));

  // Dataset state
  const [dataset, setDataset] = useState<Dataset | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  // Profiling state
  const [profile, setProfile] = useState<DatasetProfile | null>(null);
  const [profileLoading, setProfileLoading] = useState(false);
  const [profileError, setProfileError] = useState<string | null>(null);

  // Quality state
  const [quality, setQuality] = useState<Team2QualityResponse | null>(null);
  const [qualityLoading, setQualityLoading] = useState(false);
  const [qualityError, setQualityError] = useState<string | null>(null);

  // Semantic understanding state (loaded from the saved orchestration result)
  const [semantic, setSemantic] = useState<SemanticHandoffResult | null>(null);
  const [semanticLoading, setSemanticLoading] = useState(false);
  const [semanticError, setSemanticError] = useState<string | null>(null);
  const [semanticRunLoading, setSemanticRunLoading] = useState(false);
  const [selectedTarget, setSelectedTarget] = useState("");
  const [businessGoal, setBusinessGoal] = useState("");

  // Load dataset details
  const loadDataset = useCallback(
    async (signal?: AbortSignal) => {
      if (!datasetId) return;

      setLoading(true);
      setLoadError(null);

      try {
        setDataset(await getDataset(datasetId, { signal }));
      } catch (error) {
        if (!signal?.aborted) {
          setLoadError(
            error instanceof Error
              ? error.message
              : "Could not load dataset details."
          );
        }
      } finally {
        if (!signal?.aborted) {
          setLoading(false);
        }
      }
    },
    [datasetId]
  );

  useEffect(() => {
    const controller = new AbortController();

    void loadDataset(controller.signal);

    return () => controller.abort();
  }, [loadDataset]);

  // Load profiling results
  async function runProfile() {
    if (!dataset) return;

    setProfileLoading(true);
    setProfileError(null);

    try {
      const result = await getDatasetProcessingResult(dataset.id);

      if (!result.profiling) {
        throw new Error(
          "The saved processing response does not contain profiling results."
        );
      }

      setProfile(result.profiling);
      if (active.key === "semantic") {
        const semanticValue = result.semantic_analysis;
        const semanticResult = Array.isArray(semanticValue)
          ? semanticValue[0]
          : semanticValue;
        if (
          semanticResult &&
          typeof semanticResult === "object" &&
          "candidates" in semanticResult
        ) {
          setSemantic(semanticResult as SemanticHandoffResult);
          setSemanticError(null);
        } else {
          const generated = await requestTeam2Semantic({ profiles: [result.profiling] });
          const generatedResult = generated[0];
          if (!generatedResult) {
            throw new Error("Team 2 returned no semantic result for this dataset.");
          }
          setSemantic(generatedResult);
          setSemanticError(null);
        }
      }

    } catch (error) {
      setProfileError(
        error instanceof Error
          ? error.message
          : "Profiling results could not be loaded."
      );
    } finally {
      setProfileLoading(false);
    }
  }

  // Load the saved profiling result for the profiling-specific routes.
  // Each route is a separate Next.js page, so local component state is recreated
  // on navigation. Fetch the same saved result on the route that needs it.
  useEffect(() => {
    const needsProfile = [
      "overview",
      "columns",
      "distributions",
      "correlations",
      "semantic",
    ].includes(active.key);

    if (!dataset || dataset.status !== "ready" || !needsProfile) return;

    let cancelled = false;

    async function loadSavedProfile() {
      setProfileLoading(true);
      setProfileError(null);
      if (active.key === "semantic") {
        setSemanticLoading(true);
        setSemanticError(null);
      }

      try {
        const result = await getDatasetProcessingResult(dataset!.id);
        if (!result.profiling) {
          throw new Error(
            "The saved processing response does not contain profiling results."
          );
        }
        if (!cancelled) {
          setProfile(result.profiling);
          if (active.key === "semantic") {
            const semanticValue = result.semantic_analysis;
            const semanticResult = Array.isArray(semanticValue)
              ? semanticValue[0]
              : semanticValue;

            if (
              semanticResult &&
              typeof semanticResult === "object" &&
              "candidates" in semanticResult
            ) {
              setSemantic(semanticResult as SemanticHandoffResult);
            } else {
              // The processing result may contain profiling but no saved
              // semantic handoff. Run the actual Team 2 semantic endpoint.
              setSemanticRunLoading(true);
              try {
                const generated = await requestTeam2Semantic({
                  profiles: [result.profiling],
                });
                const generatedResult = generated[0];
                if (!generatedResult) {
                  throw new Error("Team 2 returned no semantic result for this dataset.");
                }
                if (!cancelled) {
                  setSemantic(generatedResult);
                  setSemanticError(null);
                }
              } catch (semanticRequestError) {
                if (!cancelled) {
                  setSemantic(null);
                  setSemanticError(
                    semanticRequestError instanceof Error
                      ? semanticRequestError.message
                      : "Semantic analysis could not be generated by Team 2."
                  );
                }
              } finally {
                if (!cancelled) setSemanticRunLoading(false);
              }
            }
          }
        }
      } catch (error) {
        if (!cancelled) {
          setProfileError(
            error instanceof Error
              ? error.message
              : "Profiling results could not be loaded."
          );
          if (active.key === "semantic") {
            setSemanticError(
              error instanceof Error
                ? error.message
                : "Semantic results could not be loaded."
            );
          }
        }
      } finally {
        if (!cancelled) {
          setProfileLoading(false);
          if (active.key === "semantic") setSemanticLoading(false);
        }
      }
    }

    void loadSavedProfile();
    return () => {
      cancelled = true;
    };
  }, [dataset, active.key]);

  // Run Team 2 Data Quality validation
  async function runQuality() {
    if (!dataset) return;

    setQualityLoading(true);
    setQualityError(null);
    setQuality(null);

    try {
      // Team 2's current POST /api/v1/quality/ schema requires a version
      // field, but its validate_dataset() implementation looks up the file
      // by dataset_id and does not use request.version. Uploaded registry
      // records currently do not include a version, so send this contract
      // placeholder only when the backend has not supplied a real version.
      const qualityResult = await requestTeam2Quality({
        dataset_id: dataset.id,
        version: dataset.version ?? TEAM2_UNVERSIONED_DATASET_VERSION,
      });

      setQuality(qualityResult);
    } catch (error) {
      setQuality(null);
      setQualityError(
        error instanceof Error
          ? error.message
          : "Data-quality validation could not be completed."
      );
    } finally {
      setQualityLoading(false);
    }
  }

  // Re-run semantic detection using the real Team 2 POST contract.
  // This computes a new proposal; the current backend package does not expose
  // the separate review-decision persistence endpoints described by the TS handoff.
  async function runSemanticWithOverrides() {
    if (!dataset || !profile) return;

    setSemanticRunLoading(true);
    setSemanticError(null);

    try {
      const results = await requestTeam2Semantic({
        profiles: [profile],
        goal: businessGoal.trim() || undefined,
        overrides: selectedTarget
          ? { [dataset.name]: selectedTarget }
          : undefined,
      });

      const nextResult = results[0];
      if (!nextResult) {
        throw new Error("Team 2 returned no semantic result for this dataset.");
      }
      setSemantic(nextResult);
    } catch (error) {
      setSemanticError(
        error instanceof Error
          ? error.message
          : "Semantic detection could not be completed."
      );
    } finally {
      setSemanticRunLoading(false);
    }
  }

  // Derived values
  const profileColumns = profile?.columns ?? [];

  const totalMissing = profileColumns.reduce(
    (sum, column) =>
      sum + (numberValue(column.missing_count) ?? 0),
    0
  );

  const datasetStats = profile?.dataset;

  const correlations = profile?.correlations;

  // Loading state
  if (loading) {
    return (
      <div className="p-8 text-sm text-slate-500">
        Loading dataset…
      </div>
    );
  }

  // Error state
  if (loadError) {
    return (
      <div className="mx-auto max-w-3xl p-6">
        <ErrorState
          title="Could not load dataset"
          message={loadError}
          onRetry={() => void loadDataset()}
        />
      </div>
    );
  }

  // Dataset not found
  if (!dataset) {
    return (
      <div className="mx-auto max-w-3xl p-6">
        <EmptyState
          title="Dataset not found"
          description="The dataset details endpoint did not return this dataset."
          action={
            <Link
              href="/datasets"
              className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white"
            >
              Back to datasets
            </Link>
          }
        />
      </div>
    );
  }

 return (
  <>
    {/* Back button outside WorkspaceLayout */}
    <div className="mb-4 px-6 pt-4">
      <Link
        href="/datasets"
        className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-indigo-700"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to datasets
      </Link>
    </div>

    <WorkspaceLayout
      title={dataset.name}
      description={`Dataset ID: ${dataset.id}`}
      navigation={navigation}
      navigationVariant="tabs"
      activeNavigationHref={pathname}
    >
      <PageHeader
        title={active.label}
        description={descriptions[active.key]}
        breadcrumb={`Datasets / ${dataset.name}`}
      />
      {dataset.status === "failed" && dataset.processing_error && (
        <div
          role="alert"
          className="mt-4 rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-800"
        >
          <p className="font-semibold">Dataset processing failed</p>
          <p className="mt-1">{dataset.processing_error}</p>
        </div>
      )}
      <div className="mt-5 space-y-6">

        {active.key === "overview" && (
          <>
        {/* Dataset overview card */}
        <section className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <span className="rounded-xl bg-indigo-50 p-3 text-indigo-700">
                <FileSpreadsheet className="h-6 w-6" />
              </span>

              <div>
                <h2 className="font-semibold text-slate-950">
                  {dataset.name}
                </h2>

                <p className="mt-1 font-mono text-xs text-slate-500">
                  {dataset.id}
                </p>

                <div className="mt-2">
                  <DatasetStatusBadge status={dataset.status} />
                </div>
              </div>
            </div>

            <p className="inline-flex items-center gap-2 text-sm text-slate-500">
              <CalendarDays className="h-4 w-4" />
              Created {formatDatasetDate(dataset.created_at)}
            </p>
          </div>

          <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <Metric
              label="Rows"
              value={formatDatasetNumber(
                numberValue(datasetStats?.row_count) ??
                  dataset.row_count
              )}
              icon={Rows3}
            />

            <Metric
              label="Columns"
              value={formatDatasetNumber(
                numberValue(datasetStats?.column_count) ??
                  dataset.column_count
              )}
              icon={Columns3}
            />

            <Metric
              label="Missing values"
              value={
                profile
                  ? totalMissing.toLocaleString()
                  : "—"
              }
              icon={TriangleAlert}
            />

            <Metric
              label="Duplicate rows"
              value={
                profile
                  ? display(datasetStats?.duplicate_row_count)
                  : "—"
              }
              icon={Database}
            />
          </div>
        </section>

          </>
        )}

        {/* Profiling section */}
        {active.key === "overview" && (
          <Panel
            title="Data profiling"
            description="Loads the saved profiling result generated automatically after upload by Team 2 background processing."
          >
            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => void runProfile()}
                disabled={
                  profileLoading || dataset.status !== "ready"
                }
                className="inline-flex items-center gap-2 rounded-lg bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-60"
              >
                {profileLoading ? (
                  <RefreshCw className="h-4 w-4 animate-spin" />
                ) : (
                  <Play className="h-4 w-4" />
                )}

                {profileLoading
                  ? "Loading results…"
                  : dataset.status !== "ready"
                    ? `Processing (${dataset.status})…`
                    : profile
                      ? "Reload profiling results"
                      : "Load profiling results"}
              </button>

              {profile && (
                <span className="inline-flex items-center gap-1 text-sm text-emerald-700">
                  <CheckCircle2 className="h-4 w-4" />
                  API status: {profile.status}
                </span>
              )}
            </div>

            {profileError && (
              <div role="alert" className="mt-3">
                <ErrorState
                  title="Profiling could not be completed"
                  message={profileError}
                  onRetry={() => void runProfile()}
                />
              </div>
            )}

            {profile && (
              <p className="mt-3 text-xs text-slate-500">
                Request {profile.request_id} · Generated{" "}
                {new Date(profile.generated_at).toLocaleString()} ·{" "}
                {display(profile.duration_ms)} ms
              </p>
            )}
          </Panel>
        )}

        {/* Column profile */}
        {profile && active.key === "columns" && (
            <Panel
              title="Column profile"
              description="Column names, inferred types, missing counts, unique counts and statistics from Team 2."
            >
              <div className="overflow-x-auto">
                <table className="min-w-[760px] w-full text-left text-sm">
                  <thead className="bg-slate-50 text-xs uppercase text-slate-500">
                    <tr>
                      {[
                        "Column",
                        "Inferred type",
                        "Data type",
                        "Missing",
                        "Missing %",
                        "Unique",
                        "Identifier?",
                      ].map((item) => (
                        <th key={item} className="px-3 py-3">
                          {item}
                        </th>
                      ))}
                    </tr>
                  </thead>

                  <tbody className="divide-y divide-slate-100">
                    {profileColumns.map((column) => (
                      <tr key={column.name}>
                        <td className="px-3 py-3 font-medium text-slate-900">
                          {column.name}
                        </td>

                        <td className="px-3 py-3">
                          {column.inferred_type}
                        </td>

                        <td className="px-3 py-3">
                          {column.dtype}
                        </td>

                        <td className="px-3 py-3 tabular-nums">
                          {display(column.missing_count)}
                        </td>

                        <td className="px-3 py-3 tabular-nums">
                          {display(column.missing_pct)}%
                        </td>

                        <td className="px-3 py-3 tabular-nums">
                          {display(column.unique_count)}
                        </td>

                        <td className="px-3 py-3">
                          {column.likely_identifier ? "Yes" : "No"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {profileColumns.length === 0 && (
                <p className="text-sm text-slate-500">
                  The profiling response did not contain column details.
                </p>
              )}

              <div className="mt-4 grid gap-3 md:grid-cols-2">
                {profileColumns
                  .filter((column) => column.summary)
                  .map((column) => (
                    <div
                      key={column.name}
                      className="rounded-xl border border-slate-200 p-4"
                    >
                      <h3 className="font-semibold">
                        {column.name} statistics
                      </h3>

                      <dl className="mt-2 grid grid-cols-2 gap-2 text-sm">
                        {Object.entries(column.summary ?? {}).map(
                          ([key, value]) => (
                            <div key={key}>
                              <dt className="text-slate-500">
                                {key.replace(/_/g, " ")}
                              </dt>

                              <dd className="font-medium">
                                {display(value)}
                              </dd>
                            </div>
                          )
                        )}
                      </dl>
                    </div>
                  ))}
              </div>
            </Panel>
          )}

        {/* Distributions */}
        {profile && active.key === "distributions" && (
          <Panel
            title="Column distributions"
            description="Numeric histograms and categorical top values returned by the profiling API."
          >
            <div className="space-y-4">
              {profileColumns.map((column) => (
                <div
                  key={column.name}
                  className="rounded-xl border border-slate-200 p-4"
                >
                  <h3 className="font-semibold">
                    {column.name}
                    <span className="ml-2 text-xs font-normal text-slate-500">
                      {column.inferred_type}
                    </span>
                  </h3>

                  {column.histogram?.length ? (
                    <div className="mt-3 flex h-36 items-end gap-1 border-b border-slate-200 pb-1">
                      {column.histogram.map((bin, index) => {
                        const max = Math.max(
                          1,
                          ...column.histogram!.map((item) => item.count)
                        );

                        return (
                          <div
                            key={index}
                            title={`${bin.start}–${bin.end}: ${bin.count}`}
                            className="flex-1 rounded-t bg-indigo-500"
                            style={{
                              height: `${Math.max(
                                2,
                                (bin.count / max) * 100
                              )}%`,
                            }}
                          />
                        );
                      })}
                    </div>
                  ) : column.top_values?.length ? (
                    <div className="mt-3 space-y-2">
                      {column.top_values.map((item, index) => (
                        <div
                          key={index}
                          className="grid grid-cols-[minmax(0,1fr)_3fr_auto] items-center gap-3 text-sm"
                        >
                          <span className="truncate">
                            {display(item.value)}
                          </span>

                          <div className="h-2 rounded bg-slate-100">
                            <div
                              className="h-2 rounded bg-indigo-500"
                              style={{
                                width: `${Math.max(
                                  0,
                                  Math.min(100, item.percentage)
                                )}%`,
                              }}
                            />
                          </div>

                          <span className="tabular-nums text-slate-500">
                            {item.percentage}%
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="mt-2 text-sm text-slate-500">
                      No distribution values returned for this column.
                    </p>
                  )}
                </div>
              ))}
            </div>
          </Panel>
        )}

        {/* Correlations */}
        {profile && active.key === "correlations" && (
          <Panel
            title="Correlation results"
            description="Correlation pairs returned by Team 2's profiling API."
          >
            <div className="overflow-x-auto">
              {correlations?.length ? (
                <table className="w-full min-w-[520px] text-left text-sm">
                  <thead className="bg-slate-50 text-xs uppercase text-slate-500">
                    <tr>
                      <th className="px-3 py-3">Column A</th>
                      <th className="px-3 py-3">Column B</th>
                      <th className="px-3 py-3">Coefficient</th>
                    </tr>
                  </thead>

                  <tbody className="divide-y divide-slate-100">
                    {correlations.map((pair, index) => (
                      <tr
                        key={`${pair.column_a}-${pair.column_b}-${index}`}
                      >
                        <td className="px-3 py-3 font-medium">
                          {pair.column_a}
                        </td>

                        <td className="px-3 py-3">
                          {pair.column_b}
                        </td>

                        <td className="px-3 py-3 tabular-nums">
                          {display(pair.coefficient)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <EmptyState
                  title="No correlations returned"
                  description="The profiling response contains no correlation pairs for this dataset."
                />
              )}
            </div>
          </Panel>
        )}

        {/* Class distribution */}
        {profile?.class_distribution &&
          active.key === "distributions" && (
            <Panel
              title="Class distribution"
              description={`Target column: ${profile.class_distribution.target_column}`}
            >
              <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                <Metric
                  label="Classes"
                  value={display(profile.class_distribution.class_count)}
                  icon={Columns3}
                />

                <Metric
                  label="Majority class"
                  value={display(profile.class_distribution.majority_class)}
                  icon={CheckCircle2}
                />

                <Metric
                  label="Minority class"
                  value={display(profile.class_distribution.minority_class)}
                  icon={TriangleAlert}
                />

                <Metric
                  label="Imbalance ratio"
                  value={display(profile.class_distribution.imbalance_ratio)}
                  icon={Database}
                />
              </div>

              <div className="mt-4 space-y-2">
                {profile.class_distribution.classes.map((item) => (
                  <div
                    key={item.value}
                    className="grid grid-cols-[minmax(0,1fr)_3fr_auto] items-center gap-3 text-sm"
                  >
                    <span className="truncate">{item.value}</span>

                    <div className="h-2 rounded bg-slate-100">
                      <div
                        className="h-2 rounded bg-indigo-500"
                        style={{
                          width: `${Math.max(
                            0,
                            Math.min(100, item.percentage)
                          )}%`,
                        }}
                      />
                    </div>

                    <span className="tabular-nums text-slate-500">
                      {item.count} ({item.percentage}%)
                    </span>
                  </div>
                ))}
              </div>

              <p className="mt-3 text-xs text-slate-500">
                Missing target values:{" "}
                {display(profile.class_distribution.missing_count)}
              </p>
            </Panel>
          )}

        {/* Quality validation */}
        {active.key === "quality" && (
          <Panel
            title="Data quality validation"
            description="Run Team 2 validation and inspect the returned violations, severity and affected records."
          >
            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => void runQuality()}
                disabled={
                  qualityLoading || dataset.status !== "ready"
                }
                className="inline-flex items-center justify-center gap-2 rounded-lg bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-60"
              >
                {qualityLoading ? (
                  <RefreshCw className="h-4 w-4 animate-spin" />
                ) : (
                  <ShieldCheck className="h-4 w-4" />
                )}

                {qualityLoading
                  ? "Validating…"
                  : "Run quality validation"}
              </button>

              <span className="text-xs text-slate-500">
                Validation is performed by the Team 2 quality API.
              </span>
            </div>

            {qualityError && (
              <div role="alert" className="mt-4">
                <ErrorState
                  title="Quality validation failed"
                  message={qualityError}
                  onRetry={() => void runQuality()}
                />
              </div>
            )}

            {quality && (
              <div className="mt-5 space-y-5">
                <div
                  className={`flex items-center gap-2 rounded-lg p-4 text-sm font-semibold ${
                    quality.status === "PASSED"
                      ? "bg-emerald-50 text-emerald-800"
                      : "bg-amber-50 text-amber-900"
                  }`}
                >
                  {quality.status === "PASSED" ? (
                    <CheckCircle2 className="h-5 w-5" />
                  ) : (
                    <XCircle className="h-5 w-5" />
                  )}
                  Validation status: {quality.status}
                </div>

                <div className="grid gap-3 sm:grid-cols-2">
                  <Metric
                    label="Total rows scanned"
                    value={formatDatasetNumber(quality.total_rows_scanned)}
                    icon={Rows3}
                  />
                  <Metric
                    label="Total violations"
                    value={formatDatasetNumber(quality.violations.length)}
                    icon={TriangleAlert}
                  />
                </div>

                <div>
                  <h3 className="mb-3 font-semibold">Detected violations</h3>
                  {quality.violations.length === 0 ? (
                    <p className="rounded-lg bg-emerald-50 p-4 text-sm text-emerald-800">
                      No quality violations detected.
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {quality.violations.map((violation, index) => (
                        <div
                          key={`${violation.rule_id}-${violation.column}-${index}`}
                          className="rounded-xl border border-slate-200 p-4"
                        >
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <h4 className="font-semibold text-slate-950">
                              {violation.rule_id}
                            </h4>
                            <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-800">
                              {violation.severity}
                            </span>
                          </div>
                          <p className="mt-2 text-sm text-slate-600">
                            {violation.description}
                          </p>
                          <div className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
                            <p>
                              <span className="text-slate-500">Column: </span>
                              <span className="font-medium">{violation.column}</span>
                            </p>
                            <p>
                              <span className="text-slate-500">Failed records: </span>
                              <span className="font-medium">{formatDatasetNumber(violation.failed_count)}</span>
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="border-t border-slate-200 pt-4 text-xs text-slate-500">
                  <p>Dataset: {quality.dataset_name}</p>
                  <p>Executed: {new Date(quality.execution_timestamp).toLocaleString()}</p>
                </div>
              </div>
            )}
          </Panel>
        )}

        {/* Semantic Understanding */}
        {active.key === "semantic" && (
          <div className="space-y-6">
            {semanticLoading && (
              <Panel title="Semantic analysis">
                <p className="text-sm text-slate-500">Loading semantic analysis from the saved Team 2 processing result…</p>
              </Panel>
            )}

            {semanticError && (
              <ErrorState
                title="Semantic analysis is not available"
                message={semanticError}
                onRetry={() => void runProfile()}
              />
            )}

            {profile && (
              <Panel
                title="Run semantic analysis"
                description="Generate or refresh semantic understanding using the saved profiling result from Team 2."
              >
                <div className="grid gap-3 rounded-xl border border-indigo-100 bg-indigo-50/50 p-4 md:grid-cols-[1fr_1fr_auto]">
                  <label className="text-sm font-medium text-slate-700">
                    Target column override
                    <select
                      value={selectedTarget}
                      onChange={(event) => setSelectedTarget(event.target.value)}
                      className="mt-1 block w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
                    >
                      <option value="">Use automatic suggestion</option>
                      {profileColumns.map((column) => (
                        <option key={column.name} value={column.name}>{column.name}</option>
                      ))}
                    </select>
                  </label>
                  <label className="text-sm font-medium text-slate-700">
                    Business goal (optional)
                    <input
                      value={businessGoal}
                      onChange={(event) => setBusinessGoal(event.target.value)}
                      placeholder="e.g. Predict employee attrition"
                      className="mt-1 block w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
                    />
                  </label>
                  <div className="flex items-end">
                    <button
                      type="button"
                      onClick={() => void runSemanticWithOverrides()}
                      disabled={semanticRunLoading || !profile}
                      className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
                    >
                      {semanticRunLoading ? "Analysing…" : semantic ? "Run again" : "Run semantic analysis"}
                    </button>
                  </div>
                </div>
                <p className="mt-2 text-xs text-slate-500">
                  This sends the selected target and business goal to Team 2. It does not save a final review decision or approve model training.
                </p>
              </Panel>
            )}

            {semantic && (
              <>
                <Panel
                  title="Target suggestion and problem type"
                  description="Team 2 identifies possible prediction targets and the likely machine-learning problem. Treat the result as a proposal until reviewed."
                >
                  <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                    <Metric label="Suggested target" value={semantic.target ?? "Not identified"} icon={Database} />
                    <Metric label="Problem type" value={semantic.problem_type.replace(/_/g, " ")} icon={ShieldCheck} />
                    <Metric label="Confidence" value={`${(semantic.confidence * 100).toFixed(1)}%`} icon={CheckCircle2} />
                    <Metric label="Target source" value={semantic.target_source.replace(/_/g, " ")} icon={FileSpreadsheet} />
                  </div>
                  <div className="mt-4 flex flex-wrap gap-2 text-xs">
                    <span className="rounded-full bg-amber-50 px-3 py-1 font-semibold text-amber-800">{semantic.status}</span>
                    <span className="rounded-full bg-slate-100 px-3 py-1 text-slate-700">Decision source: {semantic.source.replace(/_/g, " ")}</span>
                    <span className="rounded-full bg-slate-100 px-3 py-1 text-slate-700">{semantic.needs_confirmation ? "Confirmation required" : "No confirmation flagged"}</span>
                  </div>
                  {semantic.evidence?.length > 0 && (
                    <div className="mt-5">
                      <h3 className="mb-2 text-sm font-semibold">Evidence</h3>
                      <ul className="list-disc space-y-1 pl-5 text-sm text-slate-600">
                        {semantic.evidence.map((item, index) => <li key={index}>{item}</li>)}
                      </ul>
                    </div>
                  )}
                </Panel>

                <Panel
                  title="Target candidates"
                  description="Ranked target candidates returned by the semantic engine. Scores and priority labels are backend results."
                >
                  {semantic.candidates.length ? (
                    <div className="overflow-x-auto">
                      <table className="w-full min-w-[760px] text-left text-sm">
                        <thead className="bg-slate-50 text-xs uppercase text-slate-500">
                          <tr>
                            <th className="px-3 py-3">Rank</th>
                            <th className="px-3 py-3">Candidate target</th>
                            <th className="px-3 py-3">Semantic type</th>
                            <th className="px-3 py-3">Problem type</th>
                            <th className="px-3 py-3">Score</th>
                            <th className="px-3 py-3">Confidence</th>
                            <th className="px-3 py-3">Priority</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {semantic.candidates.map((candidate) => (
                            <tr key={`${candidate.rank}-${candidate.candidate_target}`}>
                              <td className="px-3 py-3">{candidate.rank}</td>
                              <td className="px-3 py-3 font-medium">{candidate.candidate_target}</td>
                              <td className="px-3 py-3">{candidate.semantic_type.replace(/_/g, " ")}</td>
                              <td className="px-3 py-3">{candidate.suggested_problem_type.replace(/_/g, " ")}</td>
                              <td className="px-3 py-3">{candidate.score.toFixed(1)}</td>
                              <td className="px-3 py-3">{candidate.confidence_level}</td>
                              <td className="px-3 py-3">{candidate.priority}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : <EmptyState title="No target candidates" description="Team 2 did not return a target candidate for this dataset." />}
                </Panel>

                <Panel title="Semantic column roles" description="Column classifications, feature eligibility, privacy flags, quality blocks and preprocessing hints.">
                  {semantic.column_roles.length ? (
                    <div className="overflow-x-auto">
                      <table className="w-full min-w-[900px] text-left text-sm">
                        <thead className="bg-slate-50 text-xs uppercase text-slate-500">
                          <tr>
                            <th className="px-3 py-3">Column</th>
                            <th className="px-3 py-3">Semantic type</th>
                            <th className="px-3 py-3">Role</th>
                            <th className="px-3 py-3">Confidence / missing</th>
                            <th className="px-3 py-3">Sensitive</th>
                            <th className="px-3 py-3">Quality blocked</th>
                            <th className="px-3 py-3">Preprocessing</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {semantic.column_roles.map((role) => (
                            <tr key={role.column}>
                              <td className="px-3 py-3 font-medium">{role.column}</td>
                              <td className="px-3 py-3">{role.semantic_type.replace(/_/g, " ")}</td>
                              <td className="px-3 py-3">{role.role}</td>
                              <td className="px-3 py-3">{role.missing_pct === null ? "—" : `${role.missing_pct}%`}</td>
                              <td className="px-3 py-3">{role.sensitive ? "Yes" : "No"}</td>
                              <td className="px-3 py-3">{role.quality_blocked ? "Yes" : "No"}</td>
                              <td className="px-3 py-3">{role.preprocessing_hint}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : <EmptyState title="No column roles" description="No semantic column-role information was returned." />}
                </Panel>

                <Panel title="Feature selection" description="Features recommended by Team 2. These are suggestions and do not automatically authorize model training.">
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="rounded-xl border border-slate-200 p-4">
                      <p className="text-sm text-slate-500">Recommended feature columns</p>
                      <p className="mt-1 text-2xl font-semibold">{semantic.recommended_feature_columns.length}</p>
                      <ul className="mt-3 space-y-1 text-sm">{semantic.recommended_feature_columns.map((name) => <li key={name}>{name}</li>)}</ul>
                    </div>
                    <div className="rounded-xl border border-slate-200 p-4">
                      <p className="text-sm text-slate-500">Approved feature columns</p>
                      <p className="mt-1 text-2xl font-semibold">{semantic.approved_feature_columns?.length ?? 0}</p>
                      <ul className="mt-3 space-y-1 text-sm">{(semantic.approved_feature_columns ?? []).map((name) => <li key={name}>{name}</li>)}</ul>
                    </div>
                  </div>
                  <p className="mt-3 text-sm text-slate-600">Feature status: <strong>{semantic.features_status.replace(/_/g, " ")}</strong></p>
                </Panel>

                <Panel title="Target leakage checks" description="Potential leakage suspects and the backend's leakage-check status.">
                  <div className="grid gap-3 sm:grid-cols-3">
                    <Metric label="Check status" value={semantic.leakage_checks.status.replace(/_/g, " ")} icon={ShieldCheck} />
                    <Metric label="Suspects" value={String(semantic.leakage_checks.suspects.length)} icon={TriangleAlert} />
                    <Metric label="Possible threshold" value={String(semantic.leakage_checks.thresholds.possible)} icon={Clock3} />
                  </div>
                  <p className="mt-3 text-sm text-slate-600">{semantic.leakage_checks.reason}</p>
                  {semantic.leakage_checks.suspects.length > 0 && (
                    <div className="mt-4 space-y-2">
                      {semantic.leakage_checks.suspects.map((suspect) => (
                        <div key={suspect.column} className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm">
                          <strong>{suspect.column}</strong> · {suspect.level} · correlation {suspect.correlation.toFixed(3)}
                          <p className="mt-1">{suspect.message}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </Panel>

                {(semantic.warnings.length > 0 || semantic.alternatives.length > 0) && (
                  <Panel title="Warnings and alternative problem types">
                    {semantic.warnings.length > 0 && <ErrorList title="Semantic warnings" items={semantic.warnings} />}
                    {semantic.alternatives.length > 0 && (
                      <div className="mt-4 space-y-2">
                        {semantic.alternatives.map((alt, index) => <div key={index} className="rounded-lg border border-slate-200 p-3 text-sm"><strong>{alt.problem_type.replace(/_/g, " ")}</strong><p className="mt-1 text-slate-600">{alt.reason}</p></div>)}
                      </div>
                    )}
                  </Panel>
                )}
              </>
            )}
          </div>
        )}

        {/* Recommendations */}
        {active.key === "recommendations" && (
          <Panel
            title="Recommendations"
            description="The current Team 2 API contract does not include a recommendations endpoint or response field."
          >
            <EmptyState
              title="Recommendations are not available yet"
              description="This page is retained in the workspace. It will display recommendations when an API contract is provided."
            />
          </Panel>
        )}

        {/* Empty profiling state */}
        {active.key !== "quality" &&
          active.key !== "recommendations" &&
          active.key !== "semantic" &&
          !profile && (
            <p className="rounded-xl border border-dashed border-slate-300 p-4 text-sm text-slate-500">
              Saved profiling results are loading for this section. If this message remains, check the profiling API response.
            </p>
          )}

        {/* Profiling warnings */}
        {active.key === "overview" && profile && profile.warnings?.length > 0 && (
          <Panel title="Profiling warnings">
            <ErrorList
              title="Warnings"
              items={profile.warnings}
            />
          </Panel>
        )}

        {/* Profiling errors */}
        {active.key === "overview" && profile && profile.errors?.length > 0 && (
          <Panel title="Profiling errors">
            <ErrorList
              title="Errors"
              items={profile.errors}
            />
          </Panel>
        )}

        {/* Navigation links */}
        <div className="flex flex-wrap gap-2">
          {sections
            .filter((item) => item.key !== active.key)
            .map((item) => (
              <Link
                key={item.key}
                href={item.slug ? `${base}/${item.slug}` : base}
                className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 hover:border-indigo-300 hover:text-indigo-700"
              >
                {item.label}
                <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            ))}
        </div>
      </div>
    </WorkspaceLayout>
    </>
  );
}
