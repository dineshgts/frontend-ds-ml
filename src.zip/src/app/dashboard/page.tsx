
import PageContainer from "@/components/layout/PageContainer";
import PageHeader from "@/components/layout/PageHeader";

export default function DashboardPage() {
  return (
    <PageContainer>
      <PageHeader
        title="Dashboard"
        description="Overview of your ML and AutoML workspace."
      />

      <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <DashboardCard
          title="Projects"
          value="0"
          description="Active projects"
        />

        <DashboardCard
          title="Datasets"
          value="0"
          description="Uploaded datasets"
        />

        <DashboardCard
          title="Experiments"
          value="0"
          description="Running experiments"
        />

        <DashboardCard
          title="Models"
          value="0"
          description="Trained models"
        />
      </section>

      <section className="mt-6 grid grid-cols-1 gap-6 xl:grid-cols-2">
        <div className="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
          <h2 className="text-lg font-semibold text-gray-900">
            Recent Projects
          </h2>

          <p className="mt-2 text-sm text-gray-500">
            Your recent ML projects will appear here.
          </p>
        </div>

        <div className="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
          <h2 className="text-lg font-semibold text-gray-900">
            Recent Experiments
          </h2>

          <p className="mt-2 text-sm text-gray-500">
            Your recent experiments will appear here.
          </p>
        </div>
      </section>
    </PageContainer>
  );
}

interface DashboardCardProps {
  title: string;
  value: string;
  description: string;
}

function DashboardCard({
  title,
  value,
  description,
}: DashboardCardProps) {
  return (
    <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
      <p className="text-sm font-medium text-gray-500">
        {title}
      </p>

      <p className="mt-2 text-2xl font-semibold text-gray-900">
        {value}
      </p>

      <p className="mt-1 text-sm text-gray-500">
        {description}
      </p>
    </div>
  );
}
