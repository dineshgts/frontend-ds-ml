import ExperimentWorkspaceView from "@/components/workspaces/ExperimentWorkspaceView";
export default function ExperimentSectionPage() { return <ExperimentWorkspaceView section="features" />; }
