"use client";

import {
  Bell,
  ChevronDown,
  Menu,
  PanelLeftClose,
  PanelLeftOpen,
  Search,
} from "lucide-react";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";

import { globalNavigation } from "@/components/navigation/navigation";

interface HeaderProps {
  sidebarCollapsed: boolean;
  onSidebarToggle: () => void;
  onMobileMenuOpen: () => void;
  context?: string;
}

export default function Header({
  sidebarCollapsed,
  onSidebarToggle,
  onMobileMenuOpen,
  context = "Dashboard",
}: HeaderProps) {
  const pathname = usePathname();

  const [searchOpen, setSearchOpen] = useState(false);

  const routeContext =
    globalNavigation
      .flatMap((group) => group.items)
      .find(
        (item) =>
          pathname === item.href ||
          pathname.startsWith(`${item.href}/`),
      )?.label ?? "Application";

  const currentContext =
    context === "Dashboard" ? routeContext : context;

  /*
   * Keyboard shortcut:
   * Ctrl + K / Cmd + K
   */
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (
        (event.ctrlKey || event.metaKey) &&
        event.key.toLowerCase() === "k"
      ) {
        event.preventDefault();
        setSearchOpen(true);
      }

      if (event.key === "Escape") {
        setSearchOpen(false);
      }
    };

    window.addEventListener("keydown", handleKeyDown);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, []);

  return (
    <header
      className={[
        "fixed inset-x-0 top-0 z-[100]",
        "h-16 md:h-[72px]",
        "border-b border-slate-200",
        "bg-white/95 backdrop-blur",
      ].join(" ")}
    >
      <div className="flex h-full items-center gap-2 px-4 sm:px-6 lg:px-8">

        {/* Mobile menu */}
        <button
          type="button"
          onClick={onMobileMenuOpen}
          aria-label="Open navigation"
          className={[
            "rounded-lg p-2",
            "text-slate-500",
            "hover:bg-slate-100 hover:text-slate-900",
            "focus-visible:outline-none",
            "focus-visible:ring-2",
            "focus-visible:ring-indigo-500",
            "lg:hidden",
          ].join(" ")}
        >
          <Menu className="h-5 w-5" />
        </button>

        {/* Desktop sidebar toggle */}
        <button
          type="button"
          onClick={onSidebarToggle}
          aria-label={
            sidebarCollapsed
              ? "Expand sidebar"
              : "Collapse sidebar"
          }
          aria-expanded={!sidebarCollapsed}
          className={[
            "hidden lg:inline-flex",
            "items-center justify-center",
            "rounded-lg p-2",
            "text-slate-500",
            "hover:bg-slate-100 hover:text-slate-900",
            "focus-visible:outline-none",
            "focus-visible:ring-2",
            "focus-visible:ring-indigo-500",
          ].join(" ")}
        >
          {sidebarCollapsed ? (
            <PanelLeftOpen className="h-5 w-5" />
          ) : (
            <PanelLeftClose className="h-5 w-5" />
          )}
        </button>

        {/* Context / breadcrumb */}
        <div className="flex min-w-0 items-center gap-2">
          <span className="hidden text-sm font-semibold text-slate-900 sm:inline">
            DataFlow
          </span>

          <span className="hidden text-slate-300 sm:inline">
            /
          </span>

          <span className="truncate text-sm text-slate-500">
            {currentContext}
          </span>
        </div>

        {/* Right actions */}
        <div className="ml-auto flex items-center gap-1 sm:gap-2">

          {/* Search */}
          <div className="relative hidden lg:block">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
            />

            <input
              aria-label="Search"
              type="search"
              placeholder="Search..."
              className={[
                "h-9 w-56 xl:w-72",
                "rounded-lg",
                "border border-slate-200",
                "bg-slate-50",
                "pl-9 pr-14",
                "text-sm text-slate-800",
                "outline-none",
                "placeholder:text-slate-400",
                "focus:border-indigo-300",
                "focus:bg-white",
                "focus:ring-2",
                "focus:ring-indigo-500/10",
              ].join(" ")}
            />

            <kbd
              className={[
                "pointer-events-none",
                "absolute right-2 top-1/2",
                "-translate-y-1/2",
                "rounded border border-slate-200",
                "bg-white px-1.5 py-0.5",
                "text-[10px] font-medium text-slate-400",
              ].join(" ")}
            >
              ⌘ K
            </kbd>
          </div>

          {/* Mobile search */}
          <button
            type="button"
            onClick={() => setSearchOpen(true)}
            aria-label="Search"
            className={[
              "rounded-lg p-2",
              "text-slate-500",
              "hover:bg-slate-100",
              "focus-visible:outline-none",
              "focus-visible:ring-2",
              "focus-visible:ring-indigo-500",
              "lg:hidden",
            ].join(" ")}
          >
            <Search className="h-5 w-5" />
          </button>

          {/* Notifications */}
          <button
            type="button"
            aria-label="Notifications"
            className={[
              "relative rounded-lg p-2",
              "text-slate-500",
              "hover:bg-slate-100 hover:text-slate-900",
              "focus-visible:outline-none",
              "focus-visible:ring-2",
              "focus-visible:ring-indigo-500",
            ].join(" ")}
          >
            <Bell className="h-5 w-5" />

            <span
              aria-hidden="true"
              className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-indigo-600"
            />
          </button>

          {/* Divider */}
          <div className="mx-1 hidden h-6 w-px bg-slate-200 sm:block" />

          {/* User */}
          <button
            type="button"
            aria-label="Open user menu"
            className={[
              "flex items-center gap-2",
              "rounded-lg p-1.5",
              "hover:bg-slate-50",
              "focus-visible:outline-none",
              "focus-visible:ring-2",
              "focus-visible:ring-indigo-500",
            ].join(" ")}
          >
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-slate-900 text-xs font-semibold text-white">
              A
            </span>

            <span className="hidden text-left sm:block">
              <span className="block text-sm font-medium text-slate-800">
                Admin
              </span>

              <span className="block text-[11px] text-slate-400">
                Administrator
              </span>
            </span>

            <ChevronDown className="hidden h-4 w-4 text-slate-400 sm:block" />
          </button>
        </div>
      </div>

      {/* Mobile search panel */}
      {searchOpen && (
        <div className="absolute left-0 right-0 top-full border-b border-slate-200 bg-white p-3 shadow-sm lg:hidden">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />

            <input
              autoFocus
              type="search"
              placeholder="Search..."
              className="h-10 w-full rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 text-sm outline-none focus:border-indigo-300 focus:bg-white focus:ring-2 focus:ring-indigo-500/10"
            />
          </div>
        </div>
      )}
    </header>
  );
}