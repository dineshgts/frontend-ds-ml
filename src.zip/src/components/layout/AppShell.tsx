"use client";

import { useState } from "react";
import type { ReactNode } from "react";

import Header from "./Header";
import MainContent from "./MainContent";
import Sidebar from "./Sidebar";

interface AppShellProps {
  children: ReactNode;
}

export default function AppShell({ children }: AppShellProps) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleMobileOpen = () => {
    setMobileOpen(true);
  };

  const handleMobileClose = () => {
    setMobileOpen(false);
  };

  const handleSidebarToggle = () => {
    setSidebarCollapsed((current) => !current);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-950">
      <Header
        sidebarCollapsed={sidebarCollapsed}
        onSidebarToggle={handleSidebarToggle}
        onMobileMenuOpen={handleMobileOpen}
      />

      <Sidebar
        collapsed={sidebarCollapsed}
        mobileOpen={mobileOpen}
        onMobileClose={handleMobileClose}
      />

      <MainContent sidebarCollapsed={sidebarCollapsed}>
        {children}
      </MainContent>
    </div>
  );
}