import type { ReactNode } from "react";

interface MainContentProps {
  children: ReactNode;
  sidebarCollapsed?: boolean;
}

export default function MainContent({
  children,
  sidebarCollapsed = false,
}: MainContentProps) {
  return (
    <main
      className={[
        "min-w-0 flex-1",
        "overflow-x-hidden overflow-y-auto",
        "pt-16 md:pt-[72px]",
        sidebarCollapsed ? "lg:pl-20" : "lg:pl-64",
        "transition-[padding-left] duration-200 ease-out",
      ].join(" ")}
    >
      {children}
    </main>
  );
}