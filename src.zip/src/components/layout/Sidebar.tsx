"use client";

import Link from "next/link";
import { X, BarChart3 } from "lucide-react";
import { usePathname } from "next/navigation";

import NavigationGroup from "@/components/navigation/NavigationGroup";
import { globalNavigation } from "@/components/navigation/navigation";

interface SidebarProps {
  collapsed: boolean;
  mobileOpen: boolean;
  onMobileClose: () => void;
}

export default function Sidebar({
  collapsed,
  mobileOpen,
  onMobileClose,
}: SidebarProps) {
  const pathname = usePathname();

  return (
    <>
      {/* Mobile overlay */}
      {mobileOpen && (
        <button
          type="button"
          aria-label="Close navigation"
          onClick={onMobileClose}
          className="fixed inset-0 z-[80] bg-slate-950/40 lg:hidden"
        />
      )}

      {/* Sidebar */}
      <aside
        aria-label="Global navigation"
        className={[
          "fixed left-0 top-0 bottom-0",
          "flex flex-col",
          "border-r border-slate-200 bg-white",
          "z-[90]",

          // Desktop width
          collapsed ? "lg:w-20" : "lg:w-64",

          // Mobile width
          "w-64",

          // Mobile drawer
          mobileOpen
            ? "translate-x-0"
            : "-translate-x-full lg:translate-x-0",

          // Animation
          "transition-[width,transform] duration-200 ease-out",
        ].join(" ")}
      >
        {/* Sidebar header */}
        <div className="flex h-16 shrink-0 items-center border-b border-slate-100 px-4 md:h-[72px]">
          <Link
            href="/dashboard"
            onClick={onMobileClose}
            className={[
              "flex min-w-0 items-center gap-3",
              collapsed ? "lg:mx-auto" : "",
            ].join(" ")}
          >
            {/* Logo */}
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-slate-900 text-white">
              <BarChart3 className="h-5 w-5" />
            </span>

            {/* Brand */}
            <span
              className={[
                "min-w-0",
                collapsed ? "lg:hidden" : "",
              ].join(" ")}
            >
              <span className="block text-sm font-bold text-slate-950">
                DataFlow
              </span>

              <span className="block text-[10px] uppercase tracking-wider text-slate-400">
                AutoML Platform
              </span>
            </span>
          </Link>

          {/* Mobile close button */}
          <button
            type="button"
            onClick={onMobileClose}
            aria-label="Close navigation"
            className="ml-auto rounded-lg p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-700 lg:hidden"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Navigation */}
        <div className="min-h-0 flex-1 overflow-y-auto px-3 py-5">
          <div className="space-y-6">
            {globalNavigation.map((group) => (
              <NavigationGroup
                key={group.title}
                group={group}
                pathname={pathname}
                collapsed={collapsed}
                onNavigate={onMobileClose}
              />
            ))}
          </div>
        </div>
      </aside>
    </>
  );
}