import type { LucideIcon } from "lucide-react";
import {
  BarChart3,
  Database,
  FileBarChart2,
  FolderKanban,
  FlaskConical,
  HelpCircle,
  LayoutDashboard,
  LineChart,
  Settings,
  Sparkles,
  Target,
} from "lucide-react";

export type NavigationItemConfig = {
  label: string;
  href: string;
  icon: LucideIcon;
  badge?: string | number;
  disabled?: boolean;
};

export type NavigationGroupConfig = {
  title: string;
  items: NavigationItemConfig[];
};

export const globalNavigation: NavigationGroupConfig[] = [
  {
    title: "Main",
    items: [
      {
        label: "Dashboard",
        href: "/dashboard",
        icon: LayoutDashboard,
      },
    ],
  },
  {
    title: "Workspace",
    items: [
      {
        label: "Projects",
        href: "/projects",
        icon: FolderKanban,
      },
      {
        label: "Datasets",
        href: "/data",
        icon: Database,
      },
      {
        label: "Experiments",
        href: "/experiments",
        icon: FlaskConical,
      },
      {
        label: "Models",
        href: "/models",
        icon: Sparkles,
      },
      {
        label: "Predictions",
        href: "/predictions",
        icon: Target,
      },
      {
        label: "Reports",
        href: "/reports",
        icon: FileBarChart2,
      },
    ],
  },
  {
    title: "System",
    items: [
      {
        label: "Settings",
        href: "/settings",
        icon: Settings,
      },
      {
        label: "Help",
        href: "/help",
        icon: HelpCircle,
      },
    ],
  },
];

export const workspaceExamples = {
  dataset: [
    { label: "Overview", href: "#overview" },
    { label: "Data Quality", href: "#data-quality" },
    { label: "Columns", href: "#columns" },
    { label: "Distributions", href: "#distributions" },
    { label: "Correlations", href: "#correlations" },
    { label: "Recommendations", href: "#recommendations" },
  ],
  experiment: [
    { label: "Problem Definition", href: "#problem-definition" },
    { label: "Preprocessing", href: "#preprocessing" },
    { label: "Features", href: "#features" },
    { label: "Models", href: "#models" },
    { label: "Evaluation", href: "#evaluation" },
    { label: "Explainability", href: "#explainability" },
    { label: "Results", href: "#results" },
  ],
} as const;
